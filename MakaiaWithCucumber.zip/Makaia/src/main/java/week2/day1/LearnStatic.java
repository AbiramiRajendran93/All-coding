package week2.day1;

import org.testng.annotations.Test;

public class LearnStatic {

	public void run() {
		System.out.println("running");
	}
	
	@Test
	public void main() {
		run();
	}

}









