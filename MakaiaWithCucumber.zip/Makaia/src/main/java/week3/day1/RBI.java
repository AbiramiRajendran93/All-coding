package week3.day1;

public interface RBI {
	
	public void aadharMandatory();

}
