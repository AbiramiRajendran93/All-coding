package week3.day1;

public class CityBank extends PayTM{

	@Override
	public void notifySMS() {
		// TODO Auto-generated method stub
		
	}

	/*public void aadharMandatory() {
		// TODO Auto-generated method stub
		
	}*/

}
