package week3.day1;

public class SBI implements RBI{
	
	public double getLoan(String whom) {
		return 1000000.00;
	}

	public void aadharMandatory() {
		// TODO Auto-generated method stub
		//return 0;
		
	}
	
//	public boolean availabilityofMoney();

}






